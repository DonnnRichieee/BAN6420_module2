Requirements:
Before running the scripts, ensure you have the following installed:
    - Python IDE
    - R or R-studio

Additionally, make sure to have the necessary libraries installed for Python and R:
    - Python: pandas
    - R: fs


Employee Data Processing:
    This project provides scripts in both Python and R for retrieving and processing employee data from a CSV file, exporting the data to a CSV file, and compressing it into a zip folder.

Python Script Usage
- Open the Python script (python_code.ipynb).
- Import pandas library
- Import the csv file
- Run the get_employee_details function 
- Enter the name of the employee when prompted.
- View the employee details displayed.
- Run the next function to export the employee details to a CSV file named "EmployeeName_details.csv" in the "Employee Profile" folder.
- A zip folder named "Employee_Profile.zip" containing the CSV file will also be created.

R Script Usage
- Run the R script (unzip_code.R).
- The script will attempt to unzip the "Employee_Profile.zip" folder.
- It will display the data from the CSV file contained within the folder.
